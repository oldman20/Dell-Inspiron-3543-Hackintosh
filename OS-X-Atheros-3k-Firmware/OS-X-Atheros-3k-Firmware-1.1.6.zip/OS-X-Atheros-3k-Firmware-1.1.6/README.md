Ath3K-OSX
=========

Atheros 3k kernel extension (kext) for mac osx lion/mountain lion - firmware upload.

Download link: https://code.google.com/p/os-x-atheros-3k-firmware/downloads/list
